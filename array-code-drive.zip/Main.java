/******************************************************************************

                            

You have an array(A) of N integer where ith index value denote the country No . 
You have another array(B) which denotes the skill of the ith person.
You have update the array B , such that B[i]=B[i]-X, where X=floor(Average skill of the country).
You have to print new array.
i/p:
7
1  1  5  3  1  3  5 
10 20 30 15 17 19 7
o/p:
-5 5 12 -2 2  2 -11
*******************************************************************************/
import java.io.*;
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
		int a[]=new int[n];
		int b[]=new int[n];
		for(int i=0;i<n;i++)
		a[i]=s.nextInt();
		for(int i=0;i<n;i++)
		b[i]=s.nextInt();
		for(int i=0;i<n;i++){
		    int count=0;
		    int curr=a[i];
		    int avg=0;
		    int sum=0;
		    for(int j=0;j<n;j++){
		        if(curr==a[j]){
		            count++;
		            sum=sum+b[j];
		        }
		    }
		    avg=sum/count;
		    System.out.print(b[i]-avg+" ");
		}
	    
	}
}
