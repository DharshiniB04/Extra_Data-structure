/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

public class Main
{
  static class node
  {
    int data;
    node L;
    node R;

      node (int d)
    {
      data = d;
      L = null;
      R = null;
    }
  }
  static node ins (node r, int d)
  {
    if (r == null)
      {
	r = new node (d);
	return r;
      }
    if (d < r.data)
      r.L = ins (r.L, d);
    else if (d > r.data)
      r.R = ins (r.R, d);
    return r;
  }
  static void player (node n, int d)
  {
    int scoreA=root.data+R.data+L.R.data+R.R.data;
    int scoreB=L.data+L.L.data+R.L.data;
    if(scoreB>scoreA)
    System.out.println(scoreA);
    else
    System.out.println(scoreB);
  }
  public static void main (String[]args)
  {
    Scanner s = new Scanner (System.in);
    node root = null;
    System.out.println ("Enter the number of nodes:");
    int n = s.nextInt ();
    
    node t = ins (root, s.nextInt ());
    System.out.println ("\nEnter node values:");
    
    for(int i=1;i<=n;i++)
      {
	a = s.nextInt ();
	ins (t, a);
	
      }
    
  }
}
