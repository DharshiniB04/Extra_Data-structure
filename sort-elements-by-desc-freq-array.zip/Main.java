public class Main {
    public static void main(String[] args) {
        int[] arr = {30, 20, 30, 10, 20, 20};

        int n = arr.length;

        // Create an array to store frequencies
        int[] frequencies = new int[n];

        // Initialize all frequencies to -1
        for (int i = 0; i < n; i++) {
            frequencies[i] = -1;
        }

        for (int i = 0; i < n; i++) {
            int count = 1;  // Count the current element
            for (int j = i + 1; j < n; j++) {
                if (arr[i] == arr[j]) {
                    count++;
                    // Mark the element as visited by setting its frequency to 0
                    frequencies[j] = 0;
                }
            }

            // If the element is not visited, set its frequency
            if (frequencies[i] != 0) {
                frequencies[i] = count;
            }
        }

        // Sort the array and frequencies in descending order
        for (int i = 0; i < n - 1; i++) {
            for (int j = i + 1; j < n; j++) {
                if (frequencies[i] < frequencies[j]) {
                    // Swap elements
                    int temp = arr[i];
                    arr[i] = arr[j];
                    arr[j] = temp;

                    // Swap frequencies
                    int tempFreq = frequencies[i];
                    frequencies[i] = frequencies[j];
                    frequencies[j] = tempFreq;
                }
            }
        }

        // Print the elements based on frequency
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < frequencies[i]; j++) {
                System.out.print(arr[i] + " ");
            }
        }
    }
}
